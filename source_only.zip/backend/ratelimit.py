"""Защита лимита kinopoisk.dev (~200 запросов/сутки на free-тарифе).

Два механизма:
  1. Дневной бюджет ВНЕШНИХ поисковых вызовов — жёсткий предохранитель под
     ~800/сутки (4 ключа × 200). Хранится в Postgres (database.try_spend_search_budget) —
     общий на все Fly-инстансы, атомарный инкремент без гонок при масштабировании.
  2. Per-user throttle — один пользователь не выжжет общую квоту. Остаётся
     in-memory (per-instance): при 2+ машинах даёт мягкую деградацию (эффективный
     лимит на юзера кратно числу машин), но это не проблема — жёсткий бюджет (п.1)
     всё равно останавливает суммарный расход вне зависимости от throttle.
"""
import os
import time
from collections import defaultdict, deque

import database as db

# Бюджет внешних поисковых вызовов в сутки. Настраивается через .env (DAILY_SEARCH_BUDGET).
DAILY_SEARCH_BUDGET: int = int(os.getenv("DAILY_SEARCH_BUDGET", "2000"))

# Per-user throttle: не более USER_MAX запросов за USER_WINDOW секунд.
USER_MAX: int = int(os.getenv("USER_SEARCH_MAX", "20"))
USER_WINDOW: int = int(os.getenv("USER_SEARCH_WINDOW", "60"))

_hits: dict[int, deque] = defaultdict(deque)
_calls: int = 0  # счётчик обращений для периодической уборки _hits


def _today() -> str:
    return time.strftime("%Y-%m-%d", time.gmtime())


async def try_spend_search() -> bool:
    """True — можно сделать внешний поисковый вызов (единица списана из общего бюджета).
    False — дневной бюджет исчерпан, внешний вызов делать нельзя."""
    return await db.try_spend_search_budget(_today(), DAILY_SEARCH_BUDGET)


def _sweep(now: float) -> None:
    """Убрать записи неактивных пользователей (иначе _hits растёт на публике)."""
    for uid in list(_hits):
        dq = _hits[uid]
        while dq and now - dq[0] > USER_WINDOW:
            dq.popleft()
        if not dq:
            del _hits[uid]


def allow_user(user_id: int) -> bool:
    """Скользящее окно: False, если пользователь превысил USER_MAX за USER_WINDOW сек."""
    global _calls
    now = time.monotonic()
    _calls += 1
    if _calls % 500 == 0:  # периодическая уборка «мёртвых» пользователей
        _sweep(now)
    dq = _hits[user_id]
    while dq and now - dq[0] > USER_WINDOW:
        dq.popleft()
    if len(dq) >= USER_MAX:
        return False
    dq.append(now)
    return True


def _reset_for_tests() -> None:
    """Только для тестов: обнулить in-memory состояние (per-user throttle)."""
    global _calls
    _calls = 0
    _hits.clear()
