"""Проверка Telegram Mini App initData (официальная схема HMAC).

Telegram подписывает данные пользователя ключом бота — подделать нельзя.
secret = HMAC_SHA256(key="WebAppData", msg=bot_token)
hash   = HMAC_SHA256(key=secret, msg=data_check_string)
"""
import hashlib
import hmac
import json
import time
from urllib.parse import parse_qsl


def validate_init_data(init_data: str, bot_token: str, max_age_sec: int = 86400) -> dict | None:
    """Возвращает dict пользователя ({'id':…, 'first_name':…}) или None, если подпись неверна."""
    if not init_data or not bot_token:
        return None
    data = dict(parse_qsl(init_data, keep_blank_values=True))
    given_hash = data.pop("hash", None)
    if not given_hash:
        return None

    check_string = "\n".join(f"{k}={v}" for k, v in sorted(data.items()))
    secret = hmac.new(b"WebAppData", bot_token.encode(), hashlib.sha256).digest()
    calc = hmac.new(secret, check_string.encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(calc, given_hash):
        return None

    # Защита от повторного использования старых initData. Требуем свежий auth_date:
    # без него (или 0) — отказ; из будущего (> небольшого допуска на рассинхрон часов)
    # — тоже отказ; старше max_age — отказ.
    try:
        auth_date = int(data.get("auth_date", "0"))
    except ValueError:
        return None
    now = time.time()
    if max_age_sec and (not auth_date or auth_date > now + 300 or now - auth_date > max_age_sec):
        return None

    try:
        return json.loads(data.get("user", "{}")) or None
    except json.JSONDecodeError:
        return None
